Name : Jaya Kishnani
NUID : 002670603


-Used an external CSS file only-Yes 
Tags Used :
1- Title :tag defines the title of the document. The title must be text-only, and it is shown in the browser's title bar or in the page's tab.
2- Image :The <img> tag is used to embed an image in an HTML page.
3- Span :tag is an inline container used to mark up a part of a text, or a part of a document.
4- ul :tag defines an unordered (bulleted) list.
5- li : tag defines a list item.
6- a :tag defines a hyperlink, which is used to link from one page to another.
7- main :The content inside the <main> element should be unique to the document. It should not contain any content that is repeated across documents such as sidebars, navigation links, copyright information, site logos, and search forms.
8- nav :tag defines a set of navigation links.
9- br :tag inserts a single line break.
10- footer :tag defines a footer for a document or section.
11-Media query:Media queries can be used to check many things, such as:

width and height of the viewport
width and height of the device
orientation (is the tablet/phone in landscape or portrait mode?)
resolution
12 -Float used :property is used for positioning and formatting content e.g. let an image float left to the text in a container.

12.Used both html and html5 elements 
13.Used :-Mail to line 195 ,Telephone line 203
14.Used table tags for languages part  in html
