Assignment 4 

Designed a form containing various validations of First Name ,last Name ,mail id ,Phone number ,city ,state ,zip code ,address 1 ,address 2 is not mandatory ,

2.Tags Used :-
1.type
2.for
3.id
4.placeholder
5.style
6.required
7.class
8.value
9.onchange
10.rows
11.cols
12.tr,th,table


2.Javascript File :-

window.addEventListener: allows you to add event listeners on any HTML DOM object such as HTML elements, the HTML document, the window object, or other objects that support events, like the xmlHttpRequest object.

Var : var is the keyword that tells JavaScript you're declaring a variable.

.htmlFor: reflects the value of the for content property.

Const : The const declaration creates block-scoped constants, much like variables declared using the let keyword.

.addEvenetListener : allows you to set up functions to be called when a specified event happens.

.innerHtml: gets or sets the HTML or XML markup contained within the element

function: a set of statements that performs a task or calculates a value

.getElementById:-The document. getElementById() method returns an Element object that represents an HTML element with an id that matches a specified string.

.checked : specifies that an <input> element should be pre-selected (checked) when the page loads. 

.onkeyup : The onkeyup attribute fires when the user releases a key (on the keyboard).



